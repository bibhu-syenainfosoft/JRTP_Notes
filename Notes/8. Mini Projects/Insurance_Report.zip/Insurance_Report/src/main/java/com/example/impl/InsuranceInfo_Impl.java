package com.example.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.model.Insurance_Info;
import com.example.model.SearchRequest;
import com.example.repo.InsuranceInfo_Repo;
import com.example.service.InsuranceInfo_Service;

@Service
public class InsuranceInfo_Impl implements InsuranceInfo_Service {

	@Autowired
	private InsuranceInfo_Repo repo;
	
	@Override
	public List<String> getPlanList() {
		return repo.getPlanList();
	}

	@Override
	public List<String> getPlanStatusList() {
		return repo.getPlanStatusList();
	}

	@Override
	public List<Insurance_Info> getSearchResultList(SearchRequest request) {
		return null;
	}

	@Override
	public boolean exportExcel() {
		return false;
	}

	@Override
	public boolean exportPdf() {
		return false;
	}

}
