package com.example.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class InsuranceReportApplication {

	public static void main(String[] args) {
		SpringApplication.run(InsuranceReportApplication.class, args);
	}

}
