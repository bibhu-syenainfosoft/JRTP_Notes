package com.example.demo;

import java.time.LocalDate;
import java.util.Arrays;

import org.springframework.boot.CommandLineRunner;

import com.example.model.Insurance_Info;
import com.example.repo.InsuranceInfo_Repo;

public class DataInserRunner implements CommandLineRunner {

	private InsuranceInfo_Repo repo;

	@Override
	public void run(String... args) throws Exception {

		Insurance_Info info1 = new Insurance_Info();
		info1.setMemberName("David");
		info1.setMemberGender("Male");
		info1.setPlanName("Cash");
		info1.setPlanStatus("Approved");
		info1.setPlanStartDate(LocalDate.now());
		info1.setPlanEndDate(LocalDate.now().plusMonths(6));
		info1.setBenefitAmount(5000.0);

		Insurance_Info info2 = new Insurance_Info();
		info2.setMemberName("Miller");
		info2.setMemberGender("Male");
		info2.setPlanName("Cash");
		info2.setPlanStatus("Terminated");
		info2.setPlanStartDate(LocalDate.now().minusMonths(4));
		info2.setPlanEndDate(LocalDate.now().plusMonths(6));
		info2.setBenefitAmount(4000.0);
		info2.setTerminatedDate(LocalDate.now());
		info2.setTerminationReason("Employed");

		Insurance_Info info3 = new Insurance_Info();
		info3.setMemberName("Johnson");
		info3.setMemberGender("Male");
		info3.setPlanName("Cash");
		info3.setPlanStatus("Denied");
		info3.setDenialReason("Rental Income");

		Insurance_Info info4 = new Insurance_Info();
		info4.setMemberName("Cathy");
		info4.setMemberGender("Female");
		info4.setPlanName("Food");
		info4.setPlanStatus("Approved");
		info4.setPlanStartDate(LocalDate.now());
		info4.setPlanEndDate(LocalDate.now().plusMonths(5));
		info4.setBenefitAmount(8000.0);

		Insurance_Info info5 = new Insurance_Info();
		info5.setMemberName("Smith");
		info5.setMemberGender("Male");
		info5.setPlanName("Food");
		info5.setPlanStatus("Denied");
		info5.setDenialReason("Property Income");

		Insurance_Info info6 = new Insurance_Info();
		info6.setMemberName("Orlen");
		info6.setMemberGender("Female");
		info6.setPlanName("Food");
		info6.setPlanStatus("Terminated");
		info6.setPlanStartDate(LocalDate.now().minusMonths(4));
		info6.setPlanEndDate(LocalDate.now().plusMonths(6));
		info6.setBenefitAmount(5000.0);
		info6.setTerminatedDate(LocalDate.now());
		info6.setTerminationReason("Employed");

		Insurance_Info info7 = new Insurance_Info();
		info7.setMemberName("Charles");
		info7.setMemberGender("Male");
		info7.setPlanName("Medical");
		info7.setPlanStatus("Approved");
		info7.setPlanStartDate(LocalDate.now());
		info7.setPlanEndDate(LocalDate.now().plusMonths(6));
		info7.setBenefitAmount(7000.0);

		Insurance_Info info8 = new Insurance_Info();
		info8.setMemberName("Robert");
		info8.setMemberGender("Male");
		info8.setPlanName("Medical");
		info8.setPlanStatus("Denied");
		info8.setDenialReason("Property Income");

		Insurance_Info info9 = new Insurance_Info();
		info9.setMemberName("Neel");
		info9.setMemberGender("Female");
		info9.setPlanName("Medical");
		info9.setPlanStatus("Terminated");
		info9.setPlanStartDate(LocalDate.now().minusMonths(6));
		info9.setPlanEndDate(LocalDate.now().plusMonths(8));
		info9.setBenefitAmount(5000.0);
		info9.setTerminatedDate(LocalDate.now());
		info9.setTerminationReason("Govt Job");

		Insurance_Info info10 = new Insurance_Info();
		info10.setMemberName("Steve");
		info10.setMemberGender("Male");
		info10.setPlanName("Employment");
		info10.setPlanStatus("Approved");
		info10.setPlanStartDate(LocalDate.now());
		info10.setPlanEndDate(LocalDate.now().plusMonths(6));
		info10.setBenefitAmount(3000.0);

		Insurance_Info info11 = new Insurance_Info();
		info11.setMemberName("Morris");
		info11.setMemberGender("Male");
		info11.setPlanName("Employment");
		info11.setPlanStatus("Denied");
		info11.setDenialReason("Property Income");

		Insurance_Info info12 = new Insurance_Info();
		info12.setMemberName("Gibs");
		info12.setMemberGender("Female");
		info12.setPlanName("Medical");
		info12.setPlanStatus("Terminated");
		info12.setPlanStartDate(LocalDate.now().minusMonths(4));
		info12.setPlanEndDate(LocalDate.now().plusMonths(6));
		info12.setBenefitAmount(7000.0);
		info12.setTerminatedDate(LocalDate.now());
		info12.setTerminationReason("Govt Job");

		repo.saveAll(Arrays.asList(info1,info2,info3,info4,info5,info6,info7,info8,info9,info10,info11,info12));
		System.out.println("Data Inserted...");	
	}

}
