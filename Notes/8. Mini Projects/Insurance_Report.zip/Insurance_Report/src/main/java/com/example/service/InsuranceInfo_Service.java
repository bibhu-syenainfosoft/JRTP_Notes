package com.example.service;

import java.util.List;

import com.example.model.Insurance_Info;
import com.example.model.SearchRequest;

public interface InsuranceInfo_Service {
	
	public List<String> getPlanList();
	public List<String> getPlanStatusList();
	public List<Insurance_Info> getSearchResultList(SearchRequest request);
	public boolean exportExcel();
	public boolean exportPdf();

}
