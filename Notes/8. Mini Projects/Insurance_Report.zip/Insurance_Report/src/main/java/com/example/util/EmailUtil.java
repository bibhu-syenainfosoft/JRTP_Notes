package com.example.util;

public class EmailUtil {

}
