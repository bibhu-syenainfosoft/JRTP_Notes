package com.example.model;

import java.time.LocalDate;
import jakarta.persistence.Entity;
import lombok.Data;

@Data
@Entity
public class Insurance_Info {
	
	private Integer memberId;
	private String memberName;
	private String memberGender;
	private String planName;
	private String planStatus;
	private LocalDate planStartDate;
	private LocalDate planEndDate;
	private Double benefitAmount;
	private String denialReason;
	private LocalDate terminatedDate;
	private String terminationReason;

}
