package com.example.repo;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.model.Insurance_Info;

public interface InsuranceInfo_Repo extends JpaRepository<Insurance_Info, Integer> {

	

}
