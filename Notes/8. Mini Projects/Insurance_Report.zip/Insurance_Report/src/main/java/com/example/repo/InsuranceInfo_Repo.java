package com.example.repo;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import com.example.model.Insurance_Info;

public interface InsuranceInfo_Repo extends JpaRepository<Insurance_Info, Integer> {

	@Query("select distinct(i.planName) from Insurance_Info i")
	public List<String> getPlanList();
	@Query("select distinct(i.planStatus) from Insurance_Info i")
	public List<String> getPlanStatusList();
	
}
