package com.example.demo;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class MyRest {
	private static final Logger logger = LoggerFactory.getLogger(MyRest.class);
	
	@GetMapping("msg")
	public ResponseEntity<String> getMsg(){
		logger.info("Info Entry*****************");
		logger.debug("Debug Entry*****************");
		try {
			int i = 10/0;
		}

		catch (Exception e) {
			logger.error("Error Msg:"+e.getMessage());
		}
		logger.debug("Debug Exit*****************");
		logger.warn("Warning*******************");
		logger.trace("Tracing******************");
		return new ResponseEntity<String>("Hi User, Welcome to Logger",HttpStatus.OK);
	}

}
