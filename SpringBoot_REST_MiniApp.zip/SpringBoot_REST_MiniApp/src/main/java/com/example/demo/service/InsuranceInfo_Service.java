package com.example.demo.service;

import java.util.List;
import java.util.Map;

import com.example.demo.model.Insurance_Info;
public interface InsuranceInfo_Service {
	
	public List<String> getPlanList();
	public List<String> getPlanStatusList();
	public Map<String, Object> getSearchResultList(String planName,String planStatus, String gender,int lowerBound,int upperBound);
	public boolean exportExcel();
	public boolean exportPdf();

}
