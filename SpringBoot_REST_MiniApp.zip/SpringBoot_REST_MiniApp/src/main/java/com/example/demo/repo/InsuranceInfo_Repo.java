package com.example.demo.repo;

import java.sql.Types;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.SqlParameter;
import org.springframework.jdbc.core.simple.SimpleJdbcCall;

import com.example.demo.model.Insurance_Info;

public interface InsuranceInfo_Repo extends JpaRepository<Insurance_Info, Integer> {
	
	@Autowired
	public static final JdbcTemplate jdbcTemplate = new JdbcTemplate();

	@Query("select distinct(i.planName) from Insurance_Info i")
	public List<String> getPlanList();
	@Query("select distinct(i.planStatus) from Insurance_Info i")
	public List<String> getPlanStatusList();
	
	public static Map<String, Object> getSearchResultList(String planName, String planStatus, String gender, int lowerBound,
			int upperBound){
		
		SimpleJdbcCall jCall = new SimpleJdbcCall(jdbcTemplate).
				withCatalogName("SPRINGBOOT_CRUD").
				withProcedureName("getInsuranceInfoList").
				declareParameters(
						new SqlParameter("planName",Types.VARCHAR),
						new SqlParameter("planStatus",Types.VARCHAR),
						new SqlParameter("gender",Types.VARCHAR),
						new SqlParameter("lowerBound",Types.NUMERIC),
						new SqlParameter("upperBound",Types.NUMERIC)
						);
		return jCall.execute(planName,planStatus,gender,lowerBound,upperBound);
	}
	
	
}
