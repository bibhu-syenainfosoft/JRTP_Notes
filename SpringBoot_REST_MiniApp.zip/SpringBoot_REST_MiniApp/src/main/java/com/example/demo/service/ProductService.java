package com.example.demo.service;

import java.util.List;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import com.example.demo.model.Authentication;
import com.example.demo.model.Product;

public interface ProductService {
public Integer SaveProduct(Product s);
public Page<Product> GetProducts(int page, int size, String sortBy, String sortDirection,String prodName);
public Product GetProductById(Integer id);
public void deleteProduct(Integer id);
public boolean existsById(Integer id);
public void updateProduct(Product prod);
public Integer UpdateCode(Integer pid,String pcode);
public boolean checkAuthentication(String userName,String password);
public List<Authentication> getAuthenticateUsers();
public Integer checkDupProduct(String pcode,Integer pid);
}
