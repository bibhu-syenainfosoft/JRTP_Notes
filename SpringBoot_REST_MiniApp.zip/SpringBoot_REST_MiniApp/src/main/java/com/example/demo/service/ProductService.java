package com.example.demo.service;

import java.util.List;

import com.example.demo.model.Authentication;
import com.example.demo.model.Product;

public interface ProductService {
public Integer SaveProduct(Product s);
public List<Product> GetProducts();
public Product GetProductById(Integer id);
public void deleteProduct(Integer id);
public boolean existsById(Integer id);
public void updateProduct(Product st);
public Integer UpdateCode(Integer pid,String pcode);
public boolean checkAuthentication(String userName,String password);
public List<Authentication> getAuthenticateUsers();
}
