package com.example.demo.repo;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.demo.model.Authentication;

public interface AuthenticateRepo extends JpaRepository<Authentication, String> {
	public Authentication findByuserNameAndPassword(String userName, String password);
}
