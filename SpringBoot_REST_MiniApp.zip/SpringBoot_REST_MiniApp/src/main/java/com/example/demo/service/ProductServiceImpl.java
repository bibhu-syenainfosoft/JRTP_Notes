package com.example.demo.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.exception.ProductNotFoundException;
import com.example.demo.model.Authentication;
import com.example.demo.model.Product;
import com.example.demo.repo.AuthenticateRepo;
import com.example.demo.repo.ProductRepo;

@Service
public class ProductServiceImpl implements ProductService {

	@Autowired
	ProductRepo repo;

	@Autowired
	AuthenticateRepo authRepo;

	@Override
	public Integer SaveProduct(Product prod) {
		Double cost=prod.getProdCost();

		var gst = cost * 12.0/100;
		var disc = cost * 20.0/100;

		prod.setProdDisc(disc);
		prod.setProdGst(gst);
		prod = repo.save(prod);
		return prod.getProdId() ;
	}

	@Override
	public List<Product> GetProducts() {
		return repo.findAll();
	}

	@Override
	public Product GetProductById(Integer id) {
		return repo.findById(id).orElseThrow(()->new ProductNotFoundException(
				new StringBuffer().append("Product ").append(id)
				.append(" Does not Exist....").toString()));
	}

	@Override
	public void deleteProduct(Integer id) {
		Optional<Product> opt = Optional.ofNullable(GetProductById(id));
		if(opt.isPresent()) {
			Product prod=GetProductById(id);
			repo.delete(prod);			
		}	
	}

	@Override
	public boolean existsById(Integer id) {
		return repo.existsById(id);
	}

	@Override
	public void updateProduct(Product prod) {
		if(prod.getProdCost()!=null && prod.getProdCost()>0) {
			var cost = prod.getProdCost();

			var gst = cost * 12.0/100;
			var disc = cost * 20.0/100;

			prod.setProdGst(gst);
			prod.setProdDisc(disc);
		}
		repo.save(prod);	
	}

	@Override
	public Integer UpdateCode(Integer pid, String pcode) {
		return repo.updateCodeById(pid, pcode);
	}

	@Override
	public boolean checkAuthentication(String userName, String password) {
		return authRepo.findByuserNameAndPassword(userName, password)!=null;
	}

	@Override
	public List<Authentication> getAuthenticateUsers() {
		return authRepo.findAll();
	}
}
