package com.example.demo.controller;

import java.io.IOException;
import java.net.URLDecoder;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.service.InsuranceInfo_Service;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;

@RestController
@CrossOrigin(origins="*")
@RequestMapping("/insurance")
public class InsuranceInfo_Controller {
	
	private static final Logger LOG = LoggerFactory.getLogger(InsuranceInfo_Controller.class);

	@Autowired
	InsuranceInfo_Service service;
	
	@Autowired
	ObjectMapper mapper;
	
	@GetMapping("/getPlanList")
	public ResponseEntity<List<Map<String, String>>> getPlanList() {
	    List<String> list = service.getPlanList();
	    List<Map<String, String>> result = new ArrayList<>();
	    
	    for (String plan : list) {
	        Map<String, String> map = new HashMap<>();
	        map.put("label", plan);
	        map.put("value", plan);
	        result.add(map);
	    }
	    
	    return new ResponseEntity<>(result, HttpStatus.OK);
	}
	
	@GetMapping("/getPlanStatusList")
	public ResponseEntity<List<Map<String, String>>> getPlanStatusList() {
	    List<String> list = service.getPlanStatusList();
	    List<Map<String, String>> result = new ArrayList<>();  
	    for (String plan : list) {
	        Map<String, String> map = new HashMap<>();
	        map.put("label", plan);
	        map.put("value", plan);
	        result.add(map);
	    }
	    return new ResponseEntity<>(result, HttpStatus.OK);
	}
	

    @GetMapping(value = "/getSearchResultList", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<Map<String, Object>> getAuthStatusList(@RequestParam String jsonObj) {
        try {
            // Remove any trailing newlines or whitespace
            jsonObj = jsonObj.trim();
            
            // URL-decode the JSON object
            String decodedJsonObj = URLDecoder.decode(jsonObj, StandardCharsets.UTF_8.name());

            // Convert JSON string to Map
            Map<String, Object> params = mapper.readValue(decodedJsonObj, new TypeReference<Map<String, Object>>() {});

            String planName = (String) params.get("planName");
            String planStatus = (String) params.get("planStatus");
            String gender = (String) params.get("gender");
            int lowerBound = (int) params.get("lowerBound");
            int upperBound = (int) params.get("upperBound");

            // Call the service method
            Map<String, Object> result = service.getSearchResultList(planName, planStatus, gender, lowerBound, upperBound);

            // Return appropriate response
            if (result.isEmpty()) {
                return new ResponseEntity<>(HttpStatus.NO_CONTENT);
            }

            return new ResponseEntity<>(result, HttpStatus.OK);
        } catch (IOException e) {
            return new ResponseEntity<>(HttpStatus.BAD_REQUEST);
        } catch (Exception e) {
            return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }
}

	 

	
	
