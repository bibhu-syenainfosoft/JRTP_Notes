package com.example.demo;

import java.util.Arrays;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

import com.example.demo.model.Authentication;
import com.example.demo.repo.AuthenticateRepo;

//@Component
public class DataInsertRunner_Authentication implements CommandLineRunner {
	
	@Autowired
	AuthenticateRepo repo;

	@Override
	public void run(String... args) throws Exception {
		
		Authentication auth1 = new Authentication();
		auth1.setUserName("Sourav");
		auth1.setPassword("Sourav@123");
		
		Authentication auth2 = new Authentication();
		auth2.setUserName("Bibhu");
		auth2.setPassword("Bibhu@123");
		
		Authentication auth3 = new Authentication();
		auth3.setUserName("Harish");
		auth3.setPassword("Harish@123");
		
		repo.saveAll(Arrays.asList(auth1,auth2,auth3));
	}

}
