package com.example.demo.model;

public class ProductUtil {
	public static void copyNonNullValues(Product db,Product request) {
		if(request.getProdCode()!=null) {
			db.setProdCode(request.getProdCode());
		}
		if(request.getProdCost()!=null) {
			db.setProdCost(request.getProdCost());
		}	
	}
}
