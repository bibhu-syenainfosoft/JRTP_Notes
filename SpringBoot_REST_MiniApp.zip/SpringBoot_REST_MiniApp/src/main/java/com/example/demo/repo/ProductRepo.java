package com.example.demo.repo;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.example.demo.model.Product;

import jakarta.transaction.Transactional;

public interface ProductRepo extends JpaRepository<Product, Integer> {
	@Modifying
	@Transactional
	@Query("UPDATE Product SET prodCode=:pcode WHERE prodId=:pid")
	public Integer updateCodeById(Integer pid,String pcode);
	
	@Query("select count(*) from Product where prodCode=upper(:pcode) and prodId!=:pid")
	public Integer checkDupProduct(String pcode,Integer pid);
	
	@Query("select p from Product p " +
		       "where (:pcode is null or p.prodCode like %:pcode%)")
		public Page<Product> getProducts(Pageable pageable, 
		                                 @Param("pcode") String prodCode);

}
