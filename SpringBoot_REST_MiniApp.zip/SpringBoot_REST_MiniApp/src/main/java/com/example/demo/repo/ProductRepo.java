package com.example.demo.repo;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;

import com.example.demo.model.Product;

import jakarta.transaction.Transactional;

public interface ProductRepo extends JpaRepository<Product, Integer> {
	@Modifying
	@Transactional
	@Query("UPDATE Product SET prodCode=:pcode WHERE prodId=:pid ")
	public Integer updateCodeById(Integer pid,String pcode);
}
