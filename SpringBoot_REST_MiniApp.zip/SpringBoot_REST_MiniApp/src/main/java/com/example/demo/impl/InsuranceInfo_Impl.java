package com.example.demo.impl;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.repo.InsuranceInfo_Repo;
import com.example.demo.service.InsuranceInfo_Service;

@Service
public class InsuranceInfo_Impl implements InsuranceInfo_Service {

	@Autowired
	private InsuranceInfo_Repo repo;

	@Override
	public List<String> getPlanList() {
		return repo.getPlanList();
	}

	@Override
	public List<String> getPlanStatusList() {
		return repo.getPlanStatusList();
	}

	@Override
	public boolean exportExcel() {
		return false;
	}

	@Override
	public boolean exportPdf() {
		return false;
	}

	@Override
	public Map<String, Object> getSearchResultList(String planName, String planStatus, String gender, int lowerBound,
			int upperBound) {
		return InsuranceInfo_Repo.getSearchResultList(planName,planStatus,gender,lowerBound,upperBound);
	}

}
