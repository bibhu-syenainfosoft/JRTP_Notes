package com.example.demo.impl;

import java.util.List;
import java.util.Optional;

import org.hibernate.query.SortDirection;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;

import com.example.demo.exception.ProductNotFoundException;
import com.example.demo.model.Authentication;
import com.example.demo.model.Product;
import com.example.demo.repo.AuthenticateRepo;
import com.example.demo.repo.ProductRepo;
import com.example.demo.service.ProductService;

@Service
public class ProductServiceImpl implements ProductService {

	@Autowired
	ProductRepo repo;

	@Autowired
	AuthenticateRepo authRepo;

	@Override
	public Integer SaveProduct(Product prod) {
		Double cost=prod.getProdCost();

		var gst = cost * 12.0/100;
		var disc = cost * 20.0/100;

		prod.setProdDisc(disc);
		prod.setProdGst(gst);
		prod = repo.save(prod);
		return prod.getProdId() ;
	}

	@Override
	public Page<Product> GetProducts(int page, int size, String sortBy, String sortDirection,String prodName) {
		Sort.Direction direction = sortDirection.equalsIgnoreCase(Sort.Direction.ASC.name()) ? Sort.Direction.ASC : Sort.Direction.DESC;
		Sort sort = Sort.by(direction,sortBy);
		Pageable pageable = PageRequest.of(page, size, sort);
		
//		if(prodName == null || "null".equals(prodName) || prodName.trim().equals("")) {
//			return repo.findAll(pageable);
//		}
//		else {
			return repo.getProducts(pageable,prodName);
//		}
	}

	@Override
	public Product GetProductById(Integer id) {
		return repo.findById(id).orElseThrow(()->new ProductNotFoundException(
				new StringBuffer().append("Product ").append(id)
				.append(" Does not Exist....").toString()));
	}

	@Override
	public void deleteProduct(Integer id) {
		Optional<Product> opt = Optional.ofNullable(GetProductById(id));
		if(opt.isPresent()) {
			Product prod=GetProductById(id);
			repo.delete(prod);			
		}	
	}

	@Override
	public boolean existsById(Integer id) {
		return repo.existsById(id);
	}

	@Override
	public void updateProduct(Product prod) {
		if(prod.getProdCost()!=null && prod.getProdCost()>0) {
			var cost = prod.getProdCost();

			var gst = cost * 12.0/100;
			var disc = cost * 20.0/100;

			prod.setProdGst(gst);
			prod.setProdDisc(disc);
		}
		repo.save(prod);	
	}

	@Override
	public Integer UpdateCode(Integer pid, String pcode) {
		return repo.updateCodeById(pid, pcode);
	}

	@Override
	public boolean checkAuthentication(String userName, String password) {
		return authRepo.findByuserNameAndPassword(userName, password)!=null;
	}

	@Override
	public List<Authentication> getAuthenticateUsers() {
		return authRepo.findAll();
	}

	@Override
	public Integer checkDupProduct(String pcode, Integer pid) {
		return repo.checkDupProduct(pcode,pid);
	}
}
