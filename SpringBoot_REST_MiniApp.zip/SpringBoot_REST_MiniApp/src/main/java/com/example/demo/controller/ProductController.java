package com.example.demo.controller;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.exception.ProductNotFoundException;
import com.example.demo.model.Authentication;
import com.example.demo.model.Product;
import com.example.demo.model.ProductUtil;
import com.example.demo.service.ProductService;

@RestController
@RequestMapping("/product")
@CrossOrigin(origins = "*")
public class ProductController {
	private static final Logger LOG=LoggerFactory.getLogger(ProductController.class);

	@Autowired
	private ProductService service;
	///@RequestMapping("/saveProduct")
	//	@PostMapping
	//	public ResponseEntity<String> saveProduct(@RequestBody Product s){
	//		Integer id=service.SaveProduct(s);
	//		return new ResponseEntity<String>("Product "+id+" Saved",HttpStatus.OK);
	//	}

	@PostMapping
	public ResponseEntity<String> saveProduct(
			@RequestBody Product prod)
	{
		LOG.info("ENTERED INTO SAVEPRODUCT METHOD");
		ResponseEntity<String> resp = null;
		try {
			Integer id =  service.SaveProduct(prod);
			resp = new ResponseEntity<String>(
					new StringBuffer()
					.append("Product '")
					.append(id)
					.append("' saved")
					.toString(),
					HttpStatus.CREATED);  //201
			LOG.info(" PRODUCT SAVED WITH ID {} ", id);
		} catch (Exception e) {
			LOG.error(" UNABLE TO SAVE PRODUCT {} " , e.getMessage());
			resp = new ResponseEntity<String>(
					"Unable to Process Save Product", 
					HttpStatus.INTERNAL_SERVER_ERROR); //500
			e.printStackTrace();
		}
		LOG.info(" ABOUT TO LEAVE SAVEPRODUCT METHOD ");
		return resp;
	}



	@RequestMapping("/getProduct")
//	@GetMapping
	public ResponseEntity<List<Product>> GetProductList(){
		List<Product> list=service.GetProducts();
		return new ResponseEntity<List<Product>>(list,HttpStatus.OK);
	}

	@RequestMapping("/getProductById/{id}")
//	@GetMapping("/{id}")
	public ResponseEntity<?> GetStudentById(@PathVariable Integer id){
		ResponseEntity<?> responseEntity=null;
		try {
			Product stu=service.GetProductById(id);
			responseEntity=new ResponseEntity<Product>(stu,HttpStatus.OK);
		}
		catch (ProductNotFoundException ee) {
			throw ee;
		}
		catch (Exception e) {
			responseEntity=new ResponseEntity<String>("Unable to fetch the Product",HttpStatus.INTERNAL_SERVER_ERROR);
			e.printStackTrace();
		}
		return responseEntity;
	}

	@RequestMapping("/deleteProduct/{id}")
//	@DeleteMapping("/{id}")
	public ResponseEntity<String> DeleteStudent(@PathVariable Integer id){
		service.deleteProduct(id);
		return ResponseEntity.ok("Record "+id+" Deleted..");
	}

	@PutMapping("/{id}")
	public ResponseEntity<String> UpdateStudent(@PathVariable Integer id,@RequestBody Product s){
		Product stu=service.GetProductById(id);
		ProductUtil.copyNonNullValues(stu, s);
		service.updateProduct(s);
		return ResponseEntity.ok("Record "+id+" Updated..");
	}
	@PatchMapping("/{code}/{id}")
	public ResponseEntity<String> UpdateCode(@PathVariable String code,@PathVariable Integer id){
		service.UpdateCode(id, code);
		return new ResponseEntity<String>("Product code "+code+" Updated..",HttpStatus.OK);
	}

	@RequestMapping("/authenticate/{userName}/{password}")
	public ResponseEntity<Boolean> authenticateUser(@PathVariable String userName,@PathVariable String password){
		boolean flag = service.checkAuthentication(userName, password);
		return new ResponseEntity<Boolean>(flag,HttpStatus.OK);
	}

	@GetMapping("/getUsersList")
	public ResponseEntity<List<Authentication>> GetUsersList(){
		List<Authentication> list=service.getAuthenticateUsers();
		return new ResponseEntity<List<Authentication>>(list,HttpStatus.OK);
	}


}
