package com.example.demo.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.hibernate.query.SortDirection;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.exception.ProductNotFoundException;
import com.example.demo.model.Authentication;
import com.example.demo.model.Product;
import com.example.demo.model.ProductUtil;
import com.example.demo.service.ProductService;

@RestController
@RequestMapping("/product")
@CrossOrigin(origins = "*")
public class ProductController {
	private static final Logger LOG = LoggerFactory.getLogger(ProductController.class);

	@Autowired
	private ProductService service;
	
//	@RequestMapping("/saveProduct")
		@PostMapping
		public ResponseEntity<Map<String, Integer>> saveProduct(@RequestBody Product prod){
			Integer id=service.SaveProduct(prod);
			Map<String, Integer> map = new HashMap<>();
			map.put("id", id);
			return new ResponseEntity<>(map,HttpStatus.OK);
		}

//	@PostMapping
//	public ResponseEntity<String> saveProduct(
//			@RequestBody Product prod)
//	{
//		LOG.info("ENTERED INTO SAVEPRODUCT METHOD");
//		ResponseEntity<String> resp = null;
//		try {
//			Integer id =  service.SaveProduct(prod);
//			resp = new ResponseEntity<String>(
//					new StringBuffer()
//					.append("Product '")
//					.append(id)
//					.append("' saved")
//					.toString(),
//					HttpStatus.CREATED);  //201
//			LOG.info(" PRODUCT SAVED WITH ID {} ", id);
//		} catch (Exception e) {
//			LOG.error(" UNABLE TO SAVE PRODUCT {} " , e.getMessage());
//			resp = new ResponseEntity<String>(
//					"Unable to Process Save Product", 
//					HttpStatus.INTERNAL_SERVER_ERROR); //500
//			e.printStackTrace();
//		}
//		LOG.info(" ABOUT TO LEAVE SAVEPRODUCT METHOD ");
//		return resp;
//	}



//	@RequestMapping("/getProduct")
////	@GetMapping
//	public ResponseEntity<List<Product>> GetProductList(){
//		List<Product> list=service.GetProducts();
//		return new ResponseEntity<List<Product>>(list,HttpStatus.OK);
//	}
	
	@RequestMapping("/getProduct")
//	@GetMapping
	public ResponseEntity<Page<Product>> GetProductList(
			@RequestParam(defaultValue = "0") int page,
			@RequestParam(defaultValue = "3") int size,
			@RequestParam(defaultValue = "prodId") String sortBy,
			@RequestParam(defaultValue = "asc") String sortDirection,
			@RequestParam(value="prodCode",required=false) String prodCode){
		Page<Product> page2 = service.GetProducts(page,size,sortBy,sortDirection,prodCode);
		return new ResponseEntity<>(page2,HttpStatus.OK);
	}

	@RequestMapping("/getProductById/{id}")
//	@GetMapping("/{id}")
	public ResponseEntity<?> GetStudentById(@PathVariable Integer id){
		ResponseEntity<?> responseEntity=null;
		try {
			Product stu=service.GetProductById(id);
			responseEntity=new ResponseEntity<Product>(stu,HttpStatus.OK);
		}
		catch (ProductNotFoundException ee) {
			throw ee;
		}
		catch (Exception e) {
			responseEntity=new ResponseEntity<String>("Unable to fetch the Product",HttpStatus.INTERNAL_SERVER_ERROR);
			e.printStackTrace();
		}
		return responseEntity;
	}

//	@RequestMapping("/deleteProduct/{id}")
	@DeleteMapping("deleteProduct/{id}")
	public ResponseEntity<Map<String, String>> deleteStudent(@PathVariable Integer id){
		service.deleteProduct(id);
		Map<String, String> map = new HashMap<>();
		map.put("Status", "Record "+id+" is Deleted Succesfully.");
		return new ResponseEntity<>(map,HttpStatus.OK);
	}

	@PutMapping("/{id}")
	public ResponseEntity<String> updateStudent(@PathVariable Integer id,@RequestBody Product s){
		Product stu=service.GetProductById(id);
		ProductUtil.copyNonNullValues(stu, s);
		service.updateProduct(s);
		return ResponseEntity.ok("Record "+id+" Updated..");
	}
	@PatchMapping("/{code}/{id}")
	public ResponseEntity<String> updateCode(@PathVariable String code,@PathVariable Integer id){
		service.UpdateCode(id, code);
		return new ResponseEntity<String>("Product code "+code+" Updated..",HttpStatus.OK);
	}

	@RequestMapping("/authenticate/{userName}/{password}")
	public ResponseEntity<Boolean> authenticateUser(@PathVariable String userName,@PathVariable String password){
		boolean flag = service.checkAuthentication(userName, password);
		return new ResponseEntity<Boolean>(flag,HttpStatus.OK);
	}

	@GetMapping("/getUsersList")
	public ResponseEntity<List<Authentication>> getUsersList(){
		List<Authentication> list=service.getAuthenticateUsers();
		return new ResponseEntity<List<Authentication>>(list,HttpStatus.OK);
	}
	
	@GetMapping("/checkDupProduct/{prodCode}/{prodId}")
	public ResponseEntity<Map<String, Integer>> checkDupProduct(@PathVariable String prodCode,@PathVariable Integer prodId){
		Integer count = service.checkDupProduct(prodCode, prodId);
		Map<String, Integer> map = new HashMap<>();
		map.put("dupCount", count);
		return new ResponseEntity<>(map,HttpStatus.OK);
	}

}
