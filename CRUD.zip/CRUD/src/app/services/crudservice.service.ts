import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class CrudserviceService {
  loggedIn: boolean = false;

  constructor(private http:HttpClient) { }

  authenticateUser(userName:string,password:string):Observable<any>{
    return this.http.get(`http://localhost:8080/product/authenticate/${userName}/${password}`);
  }
  getProdList(pageNumber:number,pageSize:number,sortBy:string,sortDirection:string,prodCode:string):Observable<any>{
    return this.http.get(`http://localhost:8080/product/getProduct?page=${pageNumber}&size=${pageSize}&sortBy=${sortBy}&sortDirection=${sortDirection}&prodCode=${prodCode}`);
  }
  getProdDetails(id:number):Observable<any>{
    return this.http.get(`http://localhost:8080/product/getProductById/${id}`);
  }
  deleteProdDetails(id:number):Observable<any>{
    return this.http.delete(`http://localhost:8080/product/deleteProduct/${id}`);
  }
  checkDupProduct(prodCode:string,prodId:number):Observable<any>{
    return this.http.get(`http://localhost:8080/product/checkDupProduct/${prodCode}/${prodId}`);
  }
  saveOrUpdateProduct(obj:any):Observable<any>{
    return this.http.post(`http://localhost:8080/product`,obj);
  }
  
  public isLoggedIn(): boolean {
    return this.loggedIn; 
  }
  public login() {
    this.loggedIn = true;
  }
  public logout() {
    this.loggedIn = false;
  }
}
