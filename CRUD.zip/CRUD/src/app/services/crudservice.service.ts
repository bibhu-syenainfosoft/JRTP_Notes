import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class CrudserviceService {
  loggedIn: boolean = false;

  constructor(private http:HttpClient) { }

  authenticateUser(userName:string,password:string):Observable<any>{
    return this.http.get(`http://localhost:8080/product/authenticate/${userName}/${password}`);
  }
  getProdList():Observable<any>{
    return this.http.get(`http://localhost:8080/product/getProduct`);
  }
  getProdDetails(id:number):Observable<any>{
    return this.http.get(`http://localhost:8080/product/getProductById/${id}`);
  }
  deleteProdDetails(id:number):Observable<any>{
    return this.http.get(`http://localhost:8080/product/deleteProduct/${id}`);
  }
  
  public isLoggedIn(): boolean {
    return this.loggedIn;
  }
  public login() {
    this.loggedIn = true;
  }
  public logout() {
    this.loggedIn = false;
  }
}
