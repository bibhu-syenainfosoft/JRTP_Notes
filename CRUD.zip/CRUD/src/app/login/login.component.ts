import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { CrudserviceService } from '../services/crudservice.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrl: './login.component.css'
})
export class LoginComponent {
  userName: any;
  password: any;
  errorMsg: any;
  msg: any;
  userErrorMsg: any;
  pwdErrorMsg: any;

  constructor(public router: Router, public crudService: CrudserviceService) { }
  ngOnInit() {
    this.userErrorMsg = ''
    this.pwdErrorMsg = '' 
    this.msg = ''
  }
  ngOnDestroy() {
    this.userErrorMsg = ''
    this.pwdErrorMsg = ''
    this.msg = ''
  }
  validate() {
    this.userErrorMsg = ''
    this.pwdErrorMsg = ''

    if (!this.userName) {
      this.userErrorMsg = 'Username cannot be Empty'
    }
    if (!this.password) {
      this.pwdErrorMsg = 'Password cannot be Empty'
    }
    if (this.userErrorMsg?.length == 0 && this.pwdErrorMsg?.length == 0) {
      this.login();
    }
  }
  login() {
    this.msg = ''
    this.crudService.authenticateUser(this.userName, this.password).subscribe(response => {
      if (response) {
        // this.router.navigate(['/crud']);
        this.router.navigate(['/crud'])
        this.msg = ''
      }
      else {
        this.msg = 'Invalid Username or Password'
      }
    })
  }
}
