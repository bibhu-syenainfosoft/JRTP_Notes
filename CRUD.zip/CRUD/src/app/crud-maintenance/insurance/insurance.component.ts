import { Component } from '@angular/core';
import { CrudserviceService } from '../../services/crudservice.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-insurance',
  templateUrl: './insurance.component.html',
  styleUrl: './insurance.component.css'
})
export class InsuranceComponent {
  planName: any;
  planStatus: any;
  gender: any;
  startDate: any;
  consumerList: any = [];
  planList: any = [];
  planStatusList: any = [];

  constructor(private crudService: CrudserviceService, private router: Router) { }
  ngOnInit() {
    this.getSearchResultList();
    this.getPlanList();
    this.getPlanStatusList();
  }

  public Genders = [
    {label: 'Male', value: 'Male'},
    {label: 'Female', value: 'Female'},
    {label: 'Other', value: 'Other'}
  ];
  public getSearchResultList() {

    const jsonObject = {
      planName: "Cash",
      planStatus: "Approved",
      gender: "Male",
      lowerBound: 1,
      upperBound: 10
  };
    this.crudService.getSearchResultList(encodeURIComponent(JSON.stringify(jsonObject))).subscribe(result => {
      this.consumerList = result;
    })
  }
  public getPlanList() {
    this.crudService.getPlanList().subscribe(result => {
      this.planList = result;
    })
  }
  public getPlanStatusList() {
    this.crudService.getPlanStatusList().subscribe(result => {
      this.planStatusList = result;
    })
  }

}
