import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { CrudCompComponent } from './crud-comp/crud-comp.component';
import { FormsModule } from '@angular/forms';
import { InputTextModule } from 'primeng/inputtext';
import { InsuranceComponent } from './insurance/insurance.component';
import { DropdownModule } from 'primeng/dropdown';
import { CalendarModule } from 'primeng/calendar';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';


@NgModule({
  declarations: [
    CrudCompComponent,
    InsuranceComponent
  ],
  imports: [
    CommonModule,
    DropdownModule,
    CalendarModule,
    BrowserAnimationsModule,
    FormsModule,
    InputTextModule
  ]
})
export class CrudMaintenanceModule { }
