import { Component } from '@angular/core';
import { CrudserviceService } from '../../services/crudservice.service';
import { Router } from '@angular/router';
@Component({
  selector: 'app-crud-comp',
  templateUrl: './crud-comp.component.html',
  styleUrl: './crud-comp.component.css'
})
export class CrudCompComponent {
  productList: any = [];
  productObj: any = {};
  editFlag: boolean = false;

  constructor(private crudService: CrudserviceService, private router: Router) { }

  ngOnInit(){
    this.getProductList();
  }
  public getProductList() {
    this.crudService.getProdList().subscribe(result => {
      this.productList = result;
    })
  }

  public getProdDetails(id:number){
    this.editFlag = true;
    this.crudService.getProdDetails(id).subscribe(result => {
      this.productObj = result;
    })
  }

  public deleteProdDetails(id:number){
    this.crudService.deleteProdDetails(id).subscribe(result => {
      this.getProductList();
    })
  }

  close(){
    this.productObj = {};
    this.editFlag = false;
  }

  public logout() {
    this.crudService.logout();
    this.router.navigate(['/login']);
  }
}
