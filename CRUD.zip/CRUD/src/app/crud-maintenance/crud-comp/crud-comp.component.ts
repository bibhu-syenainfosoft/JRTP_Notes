import { Component } from '@angular/core';
import { CrudserviceService } from '../../services/crudservice.service';
import { Router } from '@angular/router';
import Swal from 'sweetalert2';
@Component({
  selector: 'app-crud-comp',
  templateUrl: './crud-comp.component.html',
  styleUrl: './crud-comp.component.css'
})
export class CrudCompComponent {
  productList: any = [];
  productObj: any = {};
  editFlag: boolean = false;
  saveButton: boolean = false;
  pageNumber: number = 0  ;
  pageSize: number = 6;
  sortBy: any = 'prodId';
  sortDirection: any = 'asc';
  sortByOptions:number[] = [3,6,9,12];
  totalElements: any = 0;
  totalPages: any = 0;
  prodCode: any = null;

  constructor(private crudService: CrudserviceService, private router: Router) { }

  ngOnInit() {
    this.getProductList();
  }
  public getProductList() {
    this.crudService.getProdList(this.pageNumber,this.pageSize,this.sortBy,this.sortDirection,this.prodCode
    ).subscribe(result => {
      this.productList = result?.content;
      this.totalElements = result?.totalElements;
      this.totalPages = Math.ceil(this.totalElements / this.pageSize)
    })
  }

  perPageChange(event: Event){
    this.pageNumber = 0;
    this.getProductList();
  }

  goToPrevPage(){
    if(this.pageNumber > 0){
      this.pageNumber--;
      this.getProductList();
    }
  }

  goToNextPage(){
    if(this.pageNumber <= this.pageSize + 1){
      this.pageNumber++;
      this.getProductList();
    }
  }

  onSortChange(sortBy:string,sortDirection:string){
    this.sortBy = sortBy;
    this.sortDirection = sortDirection;
    this.getProductList();
  }

  public getProdDetails(id: number) {
    this.editFlag = true;
    this.crudService.getProdDetails(id).subscribe(result => {
      this.productObj = result;
    })
  }

  public validateProduct() {
    let errMsg = '';
    this.saveButton = true;

    if (!this.productObj?.prodCode?.trim()) {
      errMsg += 'Product Name cannot be empty<br>'
    }

    if (!this.productObj?.prodCost) {
      errMsg += 'Product Cost cannot be empty'
    }

    if (errMsg?.length > 0) {
      Swal.fire('Information', errMsg, 'warning')
      this.saveButton = false;
    }
    else {
      this.checkDupProduct();
    }
  }

  public checkDupProduct() {

    this.crudService.checkDupProduct(this.productObj?.prodCode,this.editFlag ? this.productObj?.prodId : 0).subscribe(res => {
      if (res?.dupCount > 0) {
        Swal.fire('Information', 'Product already exists with '+this.productObj?.prodCode+' name.', 'warning')
        this.saveButton = false;
      }
      else {
        this.saveorUpdateProduct();
      }
    })
  }

  public saveorUpdateProduct() {
    this.saveButton = true;
    let obj = {
      prodId: this.editFlag ? this.productObj?.prodId : 0,
      prodCode: this.productObj?.prodCode,
      prodCost: this.productObj?.prodCost
    }
    this.crudService.saveOrUpdateProduct(obj)?.subscribe(res => {
      if (res) {
        setTimeout(() => {
          this.saveButton = false;
        }, 2000);
        Swal.fire({
          icon: 'success',
          title: 'Success',
          text: 'Product Saved Successfully',
          showConfirmButton: false,
          timer: 2000,
          customClass: {
            popup: 'small-swal'
          }
        });
        this.close();
        this.getProductList();
      }
      else {
        Swal.fire('Information', 'Data Saved Failed', 'warning');
      }
    })
  }

  deleteProdDetails(id:number) {
    Swal.fire({
      title: 'Information',
      text: 'Are you sure you want to delete the Product?',
      icon: 'warning',
      showCancelButton: true,
      confirmButtonText: 'Yes',
      cancelButtonText: 'No',
    }).then((result) => {
      if (result.value) {
        this.crudService.deleteProdDetails(id).subscribe(res => {
          if (res?.Status) {
            Swal.fire({
              icon: 'success',
              title: 'Success',
              text: 'Product Deleted Successfully',
              showConfirmButton: false,
              timer: 2000,
              customClass: {
                popup: 'small-swal' 
              }
            });
            this.getProductList();
          }
          else {
            Swal.fire('Information', 'Data Delete Failed', 'warning');
          }
        }
        )
      }
    })
  }

  close() {
    this.productObj = {};
    this.editFlag = false;
  }
  public logout() {
    this.crudService.logout();
    this.router.navigate(['/login']);
  }

}
