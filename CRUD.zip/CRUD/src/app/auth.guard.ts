
import { Injectable } from '@angular/core';
import { ActivatedRouteSnapshot, CanActivate, GuardResult, MaybeAsync, Router, RouterStateSnapshot} from '@angular/router';
import { CrudserviceService } from './services/crudservice.service';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class AuthGuard implements CanActivate {
  constructor(private crudService: CrudserviceService, private router: Router) {}
  canActivate(): Observable<boolean> | Promise<boolean> | boolean{
  if(this.crudService.isLoggedIn()){
    return true;
  }
  else{
    this.router.navigateByUrl("login")
    return false;
  }
}
}